"""
check_injection_match.py -- compare the joint distribution of source contrast
and background column density between an injection and the real cloud.

    python3 check_injection_match.py <truth file or injection dir> \
            [<cloud dir>] [--grid <grid catalogue>] [-o fig.pdf]

The first argument may be the truth table itself or the directory holding it.
The second is the directory with the real cloud's ok.cat and add.cat, default
Aquila-Guoyin.  --grid points at bes_model_grid_final2_catalog, which supplies
each model's central column ICSDbs.

The injection is described by its truth table, which gives each core's
local_Sigma and its model tag; the model's own central column ICSDbs is read
from the grid catalogue, so the injected contrast is

    C = (ICSDbs + local_Sigma) / local_Sigma,

the same definition getsf uses, PEAK_SBF / PEAK_BGF.  The real cloud's contrast
is 1 + PEAK_SRC / PEAK_BGF from its own catalogue.

Reported: one-dimensional Kolmogorov-Smirnov statistics for each marginal, the
Spearman correlation between the two quantities in each sample, and the overlap
of the two-dimensional histograms (the Bhattacharyya coefficient, 1 for
identical distributions and 0 for disjoint ones).
"""
import sys, os, glob, argparse, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import aa_plotstyle; aa_plotstyle.apply()
from aa_plotstyle import clean_log
from scipy.stats import ks_2samp, spearmanr, gaussian_kde
import mass_correction_pipeline_5 as mc

GRID = 'cats/bes_model_grid_final2_catalog'


def grid_maps(path=GRID):
    icsd, tag = {}, {}
    hdr = None
    for l in open(path):
        if l.lstrip().startswith('#'):
            if 'ICSDbs' in l.split():
                hdr = l.lstrip('# ').split()
            continue
        if not l.strip():
            continue
        f = l.split()
        key = 'i%02dj%02dk%02d' % (int(f[1]), int(f[2]), int(f[3]))
        j = hdr.index('ICSDbs') if hdr else 25
        icsd[key] = float(f[j])
    return icsd


def _truth_path(arg):
    """Accept either the truth file itself or the directory containing it."""
    if os.path.isfile(arg):
        return arg
    hits = sorted(glob.glob(os.path.join(arg, 'inj_*_truth.txt')))
    if not hits:
        raise SystemExit('no truth table found: give either the file '
                         'inj_*_truth.txt or the directory holding it '
                         '(looked in %r)' % arg)
    return hits[0]


def injected(d, grid=None):
    icsd = grid_maps(grid or GRID)
    S, C = [], []
    for l in open(_truth_path(d)):
        if l.lstrip().startswith('#') or not l.strip():
            continue
        f = l.split()
        tag, sig = f[1], float(f[4])
        if tag in icsd and sig > 0:
            S.append(sig); C.append((icsd[tag] + sig) / sig)
    return np.array(S), np.array(C)


def real(d, stem):
    mc.VERBOSE = 0; mc.load_getsf._dist = 260.
    g = mc.load_getsf([d + '/%s.sw.sources.ok.cat' % stem,
                       d + '/%s.sw.sources.ok.add.cat' % stem])
    o = mc.source_mask(g) & (g['Nbg'] > 0) & (g['peak'] > 0) & (g['conc'] > 0)
    return g['Nbg'][o], 1.0 + g['peak'][o] / g['Nbg'][o]


def overlap2d(x1, y1, x2, y2, nb=24):
    lo = [min(x1.min(), x2.min()), min(y1.min(), y2.min())]
    hi = [max(x1.max(), x2.max()), max(y1.max(), y2.max())]
    h1, _, _ = np.histogram2d(x1, y1, bins=nb, range=[[lo[0], hi[0]], [lo[1], hi[1]]])
    h2, _, _ = np.histogram2d(x2, y2, bins=nb, range=[[lo[0], hi[0]], [lo[1], hi[1]]])
    return float(np.sum(np.sqrt((h1 / h1.sum()) * (h2 / h2.sum()))))


def contours(ax, x, y, color, label):
    k = gaussian_kde(np.vstack([x, y]))
    gx = np.linspace(x.min(), x.max(), 60)
    gy = np.linspace(y.min(), y.max(), 60)
    X, Y = np.meshgrid(gx, gy)
    Z = k(np.vstack([X.ravel(), Y.ravel()])).reshape(X.shape)
    Zs = np.sort(Z.ravel())[::-1]
    cum = np.cumsum(Zs) / Zs.sum()
    lev = [Zs[np.searchsorted(cum, f)] for f in (0.39, 0.68, 0.86)][::-1]
    ax.contour(10 ** X, 10 ** Y, Z, levels=lev, colors=color, linewidths=1.2)
    ax.plot([], [], color=color, lw=1.2, label=label)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('inj'); ap.add_argument('cloud', nargs='?', default='Aquila-Guoyin')
    ap.add_argument('--stem', default='Aquila')
    ap.add_argument('-o', default='fig_injection_match.pdf')
    ap.add_argument('--grid', default=GRID,
                    help='path to bes_model_grid_final2_catalog')
    a = ap.parse_args()
    Si, Ci = injected(a.inj, a.grid)
    if not os.path.isdir(a.cloud):
        raise SystemExit('cloud directory %r not found; pass it as the second '
                         'argument, e.g. Aquila-Guoyin' % a.cloud)
    Sr, Cr = real(a.cloud, a.stem)
    xi, yi = np.log10(Si), np.log10(Ci)
    xr, yr = np.log10(Sr), np.log10(Cr)
    print("injected cores: %d    real sources: %d\n" % (len(Si), len(Sr)))
    print("%-34s %10s %10s %12s" % ("quantity", "injected", "real", "KS / p"))
    for nm, vi, vr in (("median Sigma_cloud (cm^-2)", Si, Sr),
                       ("median contrast PEAK_SBF/PEAK_BGF", Ci, Cr)):
        ks = ks_2samp(np.log10(vi), np.log10(vr))
        print("%-34s %10.3g %10.3g %7.3f / %.1e"
              % (nm, np.median(vi), np.median(vr), ks.statistic, ks.pvalue))
    print("%-34s %10.3f %10.3f" % ("Spearman r of contrast on Sigma",
                                   spearmanr(xi, yi).statistic,
                                   spearmanr(xr, yr).statistic))
    print("%-34s %10.3f" % ("2D histogram overlap (1 = identical)",
                            overlap2d(xi, yi, xr, yr)))
    fig, ax = plt.subplots(figsize=(3.6, 3.2))
    ax.scatter(Sr, Cr, s=3, color='0.55', alpha=0.35, lw=0, label='real, %d' % len(Sr))
    ax.scatter(Si, Ci, s=6, color='crimson', alpha=0.55, lw=0,
               label='injected, %d' % len(Si))
    contours(ax, xr, yr, '0.25', None)
    contours(ax, xi, yi, 'darkred', None)
    ax.set_xscale('log'); ax.set_yscale('log'); clean_log(ax)
    ax.set_xlabel(r'$\Sigma_{\rm cloud}$  (cm$^{-2}$)', fontsize=8)
    ax.set_ylabel(r'contrast  PEAK$^{\rm SBF}$/PEAK$^{\rm BGF}$', fontsize=8)
    ax.legend(fontsize=7, loc='upper right')
    ax.tick_params(labelsize=7)
    fig.tight_layout(); fig.savefig(a.o)
    print("\nwrote %s" % a.o)


if __name__ == '__main__':
    main()
