#!/usr/bin/env python3
"""
loo_solverfix.py -- node-level leave-one-out validation of the three- and
four-observable mass correctors, on a training set built with the corrected
per-band footprint solver (see patch_band_R.py).

PROTOCOL
--------
Builds the training samples once from the production model grid.  For each node,
every sample belonging to that node is removed, both correctors are rebuilt from
the remaining samples, and the correction is evaluated on that node's single
representative sample -- the one whose footprint factor phi is closest to 1.84,
the grid's own median value.  This matches the node-LOO protocol of the paper's
validation table, so the numbers are directly comparable with it.

SPEED
-----
Rebuilding a four-dimensional Delaunay triangulation over the whole training set
once per node costs about 8 seconds per node.  It is unnecessary: piecewise
linear interpolation uses only the simplex enclosing the query point, so a
triangulation of the NLOCAL nearest training samples gives an identical answer.
The script escalates the neighbourhood (NLOCAL, then 4*NLOCAL, then the complete
remaining training set) whenever the smaller one returns a non-finite value,
which happens only if the query falls outside the local convex hull.  The result
is therefore exact, and the full run takes a few minutes on one core.

QUANTITIES REPORTED
-------------------
  M_BE        true Bonnor-Ebert mass of the node, in solar masses
  M_reported  mass the pipeline recovers for that node after footprint
              truncation and the three-band SED refit, in solar masses
  C_M,true    M_BE / M_reported
  C_M,3ax     correction factor predicted from (Sigma, zeta, phi)
  C_M,4ax     correction factor predicted from (Sigma, zeta, phi, R_BE)
  ratio       corrected (or uncorrected) mass divided by M_BE; ideal value 1

Both the raw interpolator output and the output after the pipeline's two
constraints (C_M >= 1, and the cap on the flux-recovery factor at 1/MIN_FRAC)
are reported, because those constraints were chosen when the training data still
contained the solver noise and may no longer be appropriate.

USAGE
-----
    python3 loo_solverfix.py --module mass_correction_pipeline_4d.py
"""
import argparse, importlib.util, sys, time
import numpy as np
from scipy.interpolate import LinearNDInterpolator
from scipy.spatial import cKDTree

PHI_REF = 1.84          # grid median footprint factor


def _load_module(path):
    spec = importlib.util.spec_from_file_location("mc_patched", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _interp_local(X, y, Xn, tree, keep, i, nloc):
    """Value of the piecewise linear interpolant at sample i, trained on `keep`.
    Escalates the local neighbourhood until a finite value is obtained."""
    n = len(X)
    for N in (nloc, 4 * nloc, n):
        if N >= n:
            jj = np.where(keep)[0]
        else:
            _, cand = tree.query(Xn[i], k=min(N + 200, n))
            cand = cand[keep[cand]]
            jj = cand[:N]
        if len(jj) < X.shape[1] + 2:
            continue
        try:
            v = LinearNDInterpolator(X[jj], y[jj])(X[i][None, :])[0]
        except Exception:
            v = np.nan
        if np.isfinite(v):
            return float(v)
        if N >= n:
            break
    return np.nan


def apply_caps(cm, fflux, minfrac, clamp):
    """The pipeline's two output constraints applied to a predicted C_M."""
    cm = np.asarray(cm, float).copy()
    fflux = np.asarray(fflux, float)
    if minfrac:
        over = np.isfinite(fflux) & (fflux > 1.0 / minfrac)
        cm[over] *= (1.0 / minfrac) / fflux[over]
    if clamp:
        cm = np.maximum(cm, 1.0)
    return cm


def summarize(label, ratio):
    r = np.asarray(ratio, float)
    r = r[np.isfinite(r) & (r > 0)]
    lg = np.log10(r)
    print("  %-34s n=%3d  median %.3f  scatter (factor) %.2f  "
          "within 2x %4.0f%%  median |log10 ratio| %.3f"
          % (label, len(r), np.median(r), 10 ** lg.std(),
             100 * np.mean((r > 0.5) & (r < 2.0)), np.median(np.abs(lg))))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cat', default='cats/bes_model_grid_final2_catalog')
    ap.add_argument('--rectab',
                    default='cats/bes_model_grid_final2_recovery_tables_v2')
    ap.add_argument('--module', default='mass_correction_pipeline_4d.py')
    ap.add_argument('--nlocal', type=int, default=1200)
    ap.add_argument('--stride', type=int, default=1)
    ap.add_argument('--out', default='loo_solverfix_results.csv')
    ap.add_argument('--first', type=int, default=0)
    ap.add_argument('--last', type=int, default=10**9)
    a = ap.parse_args()

    mc = _load_module(a.module)
    if not hasattr(mc, 'BANDR_DIAG'):
        sys.exit("the module at %s is NOT patched: run patch_band_R.py first"
                 % a.module)
    mc.VERBOSE = 1
    t0 = time.time()
    S = mc.build_recovery_samples(a.cat, a.rectab)
    print("\nband-footprint solver outcomes: %s" % mc.BANDR_DIAG)

    nk = np.array([str(tuple(n)) for n in S['node']])
    uniq, nid = np.unique(nk, return_inverse=True)
    X3 = np.column_stack([np.log10(S['sig']), np.log10(S['conc']),
                          np.log10(S['cfoot'])])
    X4 = np.column_stack([X3, np.log10(S['rbe_pc'])])
    ycm = np.log10(S['cm'])
    ff = S['f_flux']
    yff = np.log10(np.where(np.isfinite(ff) & (ff > 0), ff, np.nan))
    good = np.all(np.isfinite(X4), 1) & np.isfinite(ycm)
    X3, X4, ycm, yff, nid = X3[good], X4[good], ycm[good], yff[good], nid[good]
    cfoot = S['cfoot'][good]
    MBEg, Mrepg, cmtg = S['mbe'][good], S['mrec'][good], S['cm'][good]
    sg, zg, pg, rg = (S['sig'][good], S['conc'][good], S['cfoot'][good],
                      S['rbe_pc'][good])

    Xn4 = X4 / X4.std(0); tree4 = cKDTree(Xn4)
    Xn3 = X3 / X3.std(0); tree3 = cKDTree(Xn3)
    okff = np.isfinite(yff)

    tasks = []
    for u in np.unique(nid):
        idx = np.where(nid == u)[0]
        tasks.append((u, int(idx[np.argmin(np.abs(cfoot[idx] - PHI_REF))])))
    tasks = tasks[::a.stride][a.first:a.last]
    print("nodes to evaluate: %d   training samples: %d" % (len(tasks), len(ycm)))

    rows = []
    for k, (u, i) in enumerate(tasks, 1):
        keep = nid != u
        v3 = _interp_local(X3, ycm, Xn3, tree3, keep, i, a.nlocal)
        v4 = _interp_local(X4, ycm, Xn4, tree4, keep, i, a.nlocal)
        vf = _interp_local(X3, yff, Xn3, tree3, keep & okff, i, a.nlocal)
        rows.append((u, i, 10 ** v3, 10 ** v4, 10 ** vf))
        if k % 50 == 0:
            print("   %d/%d nodes done (%.1f min)" % (k, len(tasks),
                                                      (time.time() - t0) / 60),
                  flush=True)

    ir = np.array([r[1] for r in rows])
    cm3 = np.array([r[2] for r in rows]); cm4 = np.array([r[3] for r in rows])
    ffp = np.array([r[4] for r in rows])
    MBE, Mrep, cmt = MBEg[ir], Mrepg[ir], cmtg[ir]
    minfrac = mc.MIN_FRAC; clamp = getattr(mc, 'CLAMP_CM', True)
    cm3c = apply_caps(cm3, ffp, minfrac, clamp)
    cm4c = apply_caps(cm4, ffp, minfrac, clamp)

    with open(a.out, 'w') as fh:
        fh.write("# node-level leave-one-out, corrected per-band footprint solver\n")
        fh.write("# M_BE (Msun): true Bonnor-Ebert mass\n")
        fh.write("# M_reported (Msun): pipeline mass after truncation and SED refit\n")
        fh.write("# C_M_true = M_BE / M_reported\n")
        fh.write("# C_M_3ax_raw from (Sigma, zeta, phi); C_M_4ax_raw adds R_BE\n")
        fh.write("# *_cap: after the constraints C_M >= 1 and the flux-recovery cap\n")
        fh.write("# Sigma (cm^-2), zeta, phi, R_BE_pc: the corrector observables\n")
        fh.write("node_key,M_BE,M_reported,C_M_true,C_M_3ax_raw,C_M_4ax_raw,"
                 "C_M_3ax_cap,C_M_4ax_cap,Sigma,zeta,phi,R_BE_pc\n")
        for k, r in enumerate(rows):
            fh.write("%s,%.6g,%.6g,%.6g,%.6g,%.6g,%.6g,%.6g,%.6g,%.6g,%.6g,%.6g\n"
                     % (uniq[r[0]].replace(',', ' '), MBE[k], Mrep[k], cmt[k],
                        cm3[k], cm4[k], cm3c[k], cm4c[k],
                        sg[ir][k], zg[ir][k], pg[ir][k], rg[ir][k]))
    print("\nwrote %s (%d rows)" % (a.out, len(rows)))

    print("\n=== node-level leave-one-out summary ===")
    print("All ratios are mass divided by the true Bonnor-Ebert mass M_BE; the ideal")
    print("value is 1.  Scatter (factor) is 10 raised to the standard deviation of")
    print("log10(ratio) over the evaluated nodes.")
    summarize("uncorrected M_reported / M_BE", Mrep / MBE)
    summarize("3-observable, raw", Mrep * cm3 / MBE)
    summarize("4-observable, raw", Mrep * cm4 / MBE)
    summarize("3-observable, with constraints", Mrep * cm3c / MBE)
    summarize("4-observable, with constraints", Mrep * cm4c / MBE)
    lt = np.log10(cmt)
    for nm, c in (("3-observable", cm3), ("4-observable", cm4)):
        m = np.isfinite(c) & (c > 0)
        print("  correlation of log10 predicted C_M with log10 C_M_true, %-13s: %.3f"
              % (nm, np.corrcoef(np.log10(c[m]), lt[m])[0, 1]))
    print("  scatter of log10 C_M_true over the evaluated nodes: %.4f dex (factor %.3f)"
          % (lt.std(), 10 ** lt.std()))
    print("\ntotal elapsed: %.1f min" % ((time.time() - t0) / 60))


if __name__ == '__main__':
    main()
